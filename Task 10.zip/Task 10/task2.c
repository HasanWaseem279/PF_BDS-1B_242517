#include <stdio.h>
#include <string.h>
void reverse(char str[]) {
    int length = strlen(str);
    for (int i = 0; i < length / 2; i++) {
        char temp = str[i];
        str[i] = str[length - i - 1];
        str[length - i - 1] = temp;
    }
}
int main() {
    char temp[100];
    int c = 0;
    char a[] = "Hello  World";
    int len = strlen(a);
    char b[200];
    b[0] = '\0';
    for(int i = 0; i <= len; i++) {
        if (a[i] == ' ') {
            temp[c] = '\0';
            reverse(temp);
            strcat(b, temp);
            if (a[i] == ' ') {
                strcat(b, " ");
            }
            c = 0;
        } else {
            temp[c] = a[i];
            c++;
        }
    }
    printf("%s\n", b);
    return 0;
}
