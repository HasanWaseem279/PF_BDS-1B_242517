#include <stdio.h>

void Cipher(char message[], int shift) {
    for (int i = 0; message[i] != '\0'; i++) {
        message[i] = (message[i] - 'A' + shift) % 26 + 'A';
    }
}
int main() {
    char message[100];
    printf("Enter Message: ");
    scanf("%s",message);
    int shift = 3;
    Cipher(message, shift);
    printf("Encrypted message: %s\n", message);

    return 0;
}
