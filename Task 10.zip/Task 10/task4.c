#include<stdio.h>
long int DecimalToBinary(int number) {
    long int binary = 0;
    int pos = 1;

    while (number != 0) {
        int rem = number % 2;
        binary += pos * rem;
        number /= 2;
        pos *= 10;
    }
    return binary;
}
int main()
{
    int n2;
    printf("Enter your Decimal Number : ");
    scanf("%d", &n2);
    long int temp2 = DecimalToBinary(n2);
    printf("Binary : %ld\n", temp2);
}